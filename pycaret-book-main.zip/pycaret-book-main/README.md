# Simplifying Machine Learning with PyCaret
![Banner](img/banner.jpg)
Repository for the Simplifying Machine Learning with PyCaret book. Each folder contains the Python code and figures of the associated book chapter. More information about the book is available [here](https://leanpub.com/pycaretbook/).
